from collections import Counter
import pandas as pd
from decimal import Decimal


def validate_transactions(df: pd.DataFrame) -> dict:
    issues = []

    required = ["transaction_id", "transaction_date", "description", "amount", "direction"]
    missing_columns = [c for c in required if c not in df.columns]
    if missing_columns:
        issues.append({"severity": "error", "issue": "missing_columns", "details": missing_columns})
        return {"valid": False, "issues": issues}

    for idx, row in df.iterrows():
        if pd.isna(row["transaction_date"]):
            issues.append({"severity": "error", "issue": "invalid_date", "row": int(idx)})
        if not isinstance(row["amount"], Decimal):
            issues.append({"severity": "error", "issue": "invalid_amount", "row": int(idx)})
        if str(row["direction"]).lower() not in {"debit", "credit", "unknown"}:
            issues.append({"severity": "error", "issue": "invalid_direction", "row": int(idx)})

    duplicate_ids = [k for k, v in Counter(df["transaction_id"]).items() if v > 1]
    for txid in duplicate_ids:
        issues.append({"severity": "warning", "issue": "duplicate_transaction_id", "transaction_id": txid})

    duplicate_fingerprints = (
        df.astype({"transaction_date": str})
        .groupby(["transaction_date", "description", "amount", "direction"])
        .size()
    )
    for key, count in duplicate_fingerprints.items():
        if count > 1:
            issues.append({"severity": "warning", "issue": "possible_duplicate", "fingerprint": str(key), "count": int(count)})

    currencies = set(df.get("currency", pd.Series(dtype=str)).dropna())
    if len(currencies) > 1:
        issues.append({"severity": "error", "issue": "multiple_currencies", "currencies": sorted(currencies)})

    valid = not any(x["severity"] == "error" for x in issues)
    return {"valid": valid, "issues": issues}
