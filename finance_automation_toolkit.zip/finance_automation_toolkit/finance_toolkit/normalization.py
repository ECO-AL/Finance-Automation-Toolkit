import re
import unicodedata
from decimal import Decimal, InvalidOperation
import pandas as pd


ALIASES = {
    "transaction_id": ["transaction_id", "transaction id", "id", "txn id", "document number", "doc no"],
    "transaction_date": ["transaction_date", "transaction date", "date", "posting date", "value date"],
    "description": ["description", "details", "narration", "transaction description", "memo"],
    "reference": ["reference", "ref", "reference number", "transaction number", "cheque number"],
    "amount": ["amount", "value", "transaction amount", "net amount"],
    "direction": ["direction", "dr/cr", "debit credit", "type"],
    "currency": ["currency", "ccy", "currency code"],
}


def clean_column_name(name: str) -> str:
    return re.sub(r"\s+", " ", str(name).strip().lower())


def infer_column_mapping(columns) -> dict[str, str]:
    cleaned = {clean_column_name(c): c for c in columns}
    mapping = {}
    for canonical, aliases in ALIASES.items():
        for alias in aliases:
            if alias in cleaned:
                mapping[canonical] = cleaned[alias]
                break
    return mapping


def normalize_description(value) -> str:
    if pd.isna(value):
        return ""
    text = unicodedata.normalize("NFKD", str(value)).encode("ascii", "ignore").decode()
    text = text.lower()
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def parse_money(value) -> Decimal:
    if pd.isna(value) or str(value).strip() == "":
        raise InvalidOperation("Missing monetary value")
    text = str(value).strip().replace(",", "")
    return Decimal(text)


def normalize_frame(df: pd.DataFrame, mapping: dict[str, str], source: str) -> pd.DataFrame:
    required = ["transaction_date", "description", "amount"]
    missing = [field for field in required if field not in mapping]
    if missing:
        raise ValueError(f"{source}: missing required fields: {', '.join(missing)}")

    out = pd.DataFrame()
    for canonical, original in mapping.items():
        out[canonical] = df[original]

    if "transaction_id" not in out:
        out["transaction_id"] = [f"{source[:3].upper()}-{i+1:06d}" for i in range(len(out))]

    out["transaction_date"] = pd.to_datetime(out["transaction_date"], errors="coerce").dt.date
    out["description"] = out["description"].map(normalize_description)
    out["reference"] = out.get("reference", pd.Series([""] * len(out))).fillna("").astype(str).str.strip()
    out["currency"] = out.get("currency", pd.Series([""] * len(out))).fillna("").astype(str).str.upper().str.strip()

    amounts = []
    for value in out["amount"]:
        amounts.append(parse_money(value))
    out["amount"] = amounts

    if "direction" not in out:
        out["direction"] = "unknown"
    else:
        out["direction"] = (
            out["direction"].fillna("unknown").astype(str).str.lower().str.strip()
            .replace({"dr": "debit", "cr": "credit", "d": "debit", "c": "credit"})
        )

    out["source"] = source
    return out
