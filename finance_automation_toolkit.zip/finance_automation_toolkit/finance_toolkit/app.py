import pandas as pd
import streamlit as st
from decimal import Decimal
from .normalization import infer_column_mapping, normalize_frame
from .validation import validate_transactions
from .models import ReconciliationConfig
from .matching import propose_matches, detect_group_candidates
from .reconciliation import calculate_reconciliation
from .reporting import build_excel_report, build_pdf_report

st.set_page_config(page_title="Finance Automation Toolkit", layout="wide")
st.title("Finance Automation Toolkit")
st.caption("Bank reconciliation with transparent matching and accountant controlled approval.")

if "approved_pairs" not in st.session_state:
    st.session_state.approved_pairs = []
if "audit" not in st.session_state:
    st.session_state.audit = []

bank_file = st.file_uploader("Upload bank statement", type=["csv", "xlsx"])
ledger_file = st.file_uploader("Upload general ledger export", type=["csv", "xlsx"])

with st.sidebar:
    st.header("Reconciliation settings")
    date_tolerance = st.number_input("Date tolerance in days", min_value=0, max_value=30, value=2)
    amount_tolerance = st.number_input("Amount tolerance", min_value=0.0, value=0.01, step=0.01, format="%.2f")
    description_threshold = st.slider("Description similarity threshold", 0.0, 1.0, 0.72, 0.01)

def read_upload(upload):
    if upload.name.lower().endswith(".csv"):
        return pd.read_csv(upload)
    return pd.read_excel(upload)

if bank_file and ledger_file:
    bank_raw = read_upload(bank_file)
    ledger_raw = read_upload(ledger_file)

    st.subheader("Column mapping")
    bank_map = infer_column_mapping(bank_raw.columns)
    ledger_map = infer_column_mapping(ledger_raw.columns)

    st.write("Detected bank mapping:", bank_map)
    st.write("Detected ledger mapping:", ledger_map)

    if st.button("Validate and propose matches"):
        try:
            bank = normalize_frame(bank_raw, bank_map, "bank")
            ledger = normalize_frame(ledger_raw, ledger_map, "ledger")
            bank_validation = validate_transactions(bank)
            ledger_validation = validate_transactions(ledger)

            st.session_state.bank = bank
            st.session_state.ledger = ledger
            st.session_state.bank_validation = bank_validation
            st.session_state.ledger_validation = ledger_validation

            if not bank_validation["valid"] or not ledger_validation["valid"]:
                st.error("Correct data quality errors before reconciliation.")
            else:
                config = ReconciliationConfig(
                    date_tolerance_days=date_tolerance,
                    amount_tolerance=Decimal(str(amount_tolerance)),
                    description_threshold=description_threshold
                )
                proposals = propose_matches(bank, ledger, config)
                groups = detect_group_candidates(bank, ledger, config)
                st.session_state.proposals = proposals
                st.session_state.groups = groups
                st.session_state.approved_pairs = []
                st.session_state.audit = []
                st.success("Validation completed and matching proposals generated.")
        except Exception as exc:
            st.error(f"Processing error: {exc}")

if "bank_validation" in st.session_state:
    st.subheader("Data quality")
    for label, validation in [
        ("Bank", st.session_state.bank_validation),
        ("Ledger", st.session_state.ledger_validation)
    ]:
        errors = [x for x in validation["issues"] if x["severity"] == "error"]
        warnings = [x for x in validation["issues"] if x["severity"] == "warning"]
        st.write(f"{label}: {len(errors)} errors, {len(warnings)} warnings")

if "proposals" in st.session_state:
    st.subheader("Transaction review")
    proposals = st.session_state.proposals
    bank = st.session_state.bank
    ledger = st.session_state.ledger

    for i, proposal in enumerate(proposals):
        if not proposal.ledger_ids:
            continue
        if proposal.status == "proposed":
            with st.expander(f"{proposal.bank_id} | Confidence {proposal.score:.0%}"):
                st.write("Evidence:", ", ".join(proposal.evidence))
                if st.button("Approve", key=f"approve_{i}"):
                    st.session_state.approved_pairs.append((proposal.bank_id, proposal.ledger_ids[0]))
                    st.session_state.audit.append({
                        "transaction_type": "match",
                        "transaction_id": proposal.bank_id,
                        "action": "approve",
                        "decision": "approved",
                        "evidence": proposal.evidence,
                        "user": "accountant"
                    })
                    st.rerun()
                if st.button("Reject", key=f"reject_{i}"):
                    st.session_state.audit.append({
                        "transaction_type": "match",
                        "transaction_id": proposal.bank_id,
                        "action": "reject",
                        "decision": "rejected",
                        "evidence": proposal.evidence,
                        "user": "accountant"
                    })
                    st.rerun()

    if st.button("Calculate reconciliation"):
        result = calculate_reconciliation(bank, ledger, st.session_state.approved_pairs)
        st.session_state.result = result

if "result" in st.session_state:
    result = st.session_state.result
    st.subheader("Reconciliation summary")
    cols = st.columns(4)
    cols[0].metric("Bank total", f"{result.bank_total}")
    cols[1].metric("Ledger total", f"{result.ledger_total}")
    cols[2].metric("Difference", f"{result.difference}")
    cols[3].metric("Status", result.status)

    exceptions = []
    approved_bank = {x[0] for x in st.session_state.approved_pairs}
    approved_ledger = {x[1] for x in st.session_state.approved_pairs}

    for _, row in st.session_state.bank.iterrows():
        if str(row.transaction_id) not in approved_bank:
            exceptions.append({
                "source": "bank",
                "transaction_id": str(row.transaction_id),
                "exception": "unmatched bank transaction",
                "amount": str(row.amount)
            })

    for _, row in st.session_state.ledger.iterrows():
        if str(row.transaction_id) not in approved_ledger:
            exceptions.append({
                "source": "ledger",
                "transaction_id": str(row.transaction_id),
                "exception": "unmatched ledger transaction",
                "amount": str(row.amount)
            })

    excel = build_excel_report(result, st.session_state.proposals, exceptions)
    pdf = build_pdf_report(result, st.session_state.proposals, exceptions)

    st.download_button("Download Excel report", excel.getvalue(), "reconciliation_report.xlsx")
    st.download_button("Download PDF report", pdf.getvalue(), "reconciliation_report.pdf")

    st.subheader("Exceptions")
    st.dataframe(pd.DataFrame(exceptions), use_container_width=True)

    st.subheader("Audit trail")
    st.dataframe(pd.DataFrame(st.session_state.audit), use_container_width=True)
