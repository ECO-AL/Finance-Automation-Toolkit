from datetime import timedelta
from decimal import Decimal
from difflib import SequenceMatcher
from itertools import combinations
from .models import MatchProposal, ReconciliationConfig


def _description_similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, a or "", b or "").ratio()


def _same_direction(a, b) -> bool:
    return a == "unknown" or b == "unknown" or a == b


def _amount_close(a: Decimal, b: Decimal, tolerance: Decimal) -> bool:
    return abs(a - b) <= tolerance


def score_pair(bank, ledger, config: ReconciliationConfig):
    evidence = []
    score = 0.0

    if not _same_direction(bank.direction, ledger.direction):
        return 0.0, ["direction mismatch"]

    if _amount_close(bank.amount, ledger.amount, config.amount_tolerance):
        score += 0.45
        evidence.append("amount matches within tolerance")
    else:
        return 0.0, ["amount outside tolerance"]

    date_diff = abs((bank.transaction_date - ledger.transaction_date).days)
    if date_diff == 0:
        score += 0.25
        evidence.append("date exact")
    elif date_diff <= config.date_tolerance_days:
        score += 0.15
        evidence.append(f"date within {config.date_tolerance_days} days")
    else:
        return 0.0, ["date outside tolerance"]

    bank_ref = str(bank.reference).strip().lower()
    ledger_ref = str(ledger.reference).strip().lower()
    if bank_ref and ledger_ref and bank_ref == ledger_ref:
        score += 0.25
        evidence.append("reference exact")
    elif bank_ref and ledger_ref and (bank_ref in ledger_ref or ledger_ref in bank_ref):
        score += 0.12
        evidence.append("reference partially matches")

    sim = _description_similarity(bank.description, ledger.description)
    if sim >= config.description_threshold:
        score += 0.15
        evidence.append(f"description similarity {sim:.2f}")
    elif sim >= 0.5:
        score += 0.05
        evidence.append(f"weak description similarity {sim:.2f}")

    return min(score, 1.0), evidence


def propose_matches(bank_df, ledger_df, config: ReconciliationConfig) -> list[MatchProposal]:
    proposals = []
    used_ledger = set()

    for _, bank in bank_df.iterrows():
        candidates = []
        for _, ledger in ledger_df.iterrows():
            if ledger.transaction_id in used_ledger:
                continue
            score, evidence = score_pair(bank, ledger, config)
            if score > 0:
                candidates.append((score, ledger, evidence))

        candidates.sort(key=lambda x: x[0], reverse=True)

        if not candidates:
            proposals.append(MatchProposal(str(bank.transaction_id), [], 0.0, "unmatched", ["no viable candidate"]))
            continue

        best_score, best_ledger, best_evidence = candidates[0]
        tied = [c for c in candidates if abs(c[0] - best_score) < 0.001]

        if len(tied) > 1:
            proposals.append(MatchProposal(
                str(bank.transaction_id),
                [str(c[1].transaction_id) for c in tied],
                best_score,
                "manual_review",
                ["ambiguous candidates"] + best_evidence
            ))
        elif best_score >= 0.75:
            proposals.append(MatchProposal(
                str(bank.transaction_id),
                [str(best_ledger.transaction_id)],
                best_score,
                "proposed",
                best_evidence
            ))
        else:
            proposals.append(MatchProposal(
                str(bank.transaction_id),
                [str(best_ledger.transaction_id)],
                best_score,
                "manual_review",
                best_evidence
            ))

    return proposals


def detect_group_candidates(bank_df, ledger_df, config: ReconciliationConfig):
    if not config.enable_group_matching:
        return []

    candidates = []
    for _, bank in bank_df.iterrows():
        available = ledger_df[
            (ledger_df["transaction_date"].apply(
                lambda d: abs((bank.transaction_date - d).days) <= config.date_tolerance_days
            ))
            & (ledger_df["direction"].apply(lambda d: _same_direction(bank.direction, d)))
        ]

        rows = list(available.itertuples(index=False))
        for size in range(2, config.max_group_size + 1):
            for group in combinations(rows, size):
                total = sum((x.amount for x in group), Decimal("0"))
                if _amount_close(bank.amount, total, config.amount_tolerance):
                    candidates.append({
                        "bank_id": str(bank.transaction_id),
                        "ledger_ids": [str(x.transaction_id) for x in group],
                        "type": "many_to_one"
                    })
    return candidates
