from decimal import Decimal
from .models import ReconciliationResult


def calculate_reconciliation(bank_df, ledger_df, approved_pairs):
    matched_bank_ids = {p[0] for p in approved_pairs}
    matched_ledger_ids = {p[1] for p in approved_pairs}

    bank_total = sum(bank_df["amount"], Decimal("0"))
    ledger_total = sum(ledger_df["amount"], Decimal("0"))

    matched_bank_total = sum(
        (row.amount for _, row in bank_df.iterrows() if str(row.transaction_id) in matched_bank_ids),
        Decimal("0")
    )
    matched_ledger_total = sum(
        (row.amount for _, row in ledger_df.iterrows() if str(row.transaction_id) in matched_ledger_ids),
        Decimal("0")
    )

    unmatched_bank_total = bank_total - matched_bank_total
    unmatched_ledger_total = ledger_total - matched_ledger_total
    difference = bank_total - ledger_total

    status = "RECONCILED" if difference == Decimal("0") and unmatched_bank_total == Decimal("0") and unmatched_ledger_total == Decimal("0") else "UNRECONCILED"

    return ReconciliationResult(
        bank_total, ledger_total, matched_bank_total, matched_ledger_total,
        unmatched_bank_total, unmatched_ledger_total, difference, status
    )
