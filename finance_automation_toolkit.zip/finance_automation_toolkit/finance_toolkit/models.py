from dataclasses import dataclass
from decimal import Decimal
from datetime import date
from typing import Optional


@dataclass(frozen=True)
class ReconciliationConfig:
    date_tolerance_days: int = 2
    amount_tolerance: Decimal = Decimal("0.01")
    description_threshold: float = 0.72
    enable_group_matching: bool = True
    max_group_size: int = 3


@dataclass
class MatchProposal:
    bank_id: str
    ledger_ids: list[str]
    score: float
    status: str
    evidence: list[str]


@dataclass
class AuditEvent:
    transaction_type: str
    transaction_id: str
    action: str
    decision: str
    evidence: list[str]
    user: str = "system"


@dataclass
class ReconciliationResult:
    bank_total: Decimal
    ledger_total: Decimal
    matched_bank_total: Decimal
    matched_ledger_total: Decimal
    unmatched_bank_total: Decimal
    unmatched_ledger_total: Decimal
    difference: Decimal
    status: str
