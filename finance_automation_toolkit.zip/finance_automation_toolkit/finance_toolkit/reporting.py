from io import BytesIO
from decimal import Decimal
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet


def proposals_to_frame(proposals):
    return pd.DataFrame([{
        "bank_id": p.bank_id,
        "ledger_ids": ", ".join(p.ledger_ids),
        "score": round(p.score, 3),
        "status": p.status,
        "evidence": "; ".join(p.evidence)
    } for p in proposals])


def build_excel_report(result, proposals, exceptions):
    buffer = BytesIO()
    summary = pd.DataFrame({
        "Metric": [
            "Bank total", "Ledger total", "Matched bank total",
            "Matched ledger total", "Unmatched bank total",
            "Unmatched ledger total", "Difference", "Status"
        ],
        "Value": [
            result.bank_total, result.ledger_total,
            result.matched_bank_total, result.matched_ledger_total,
            result.unmatched_bank_total, result.unmatched_ledger_total,
            result.difference, result.status
        ]
    })

    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        summary.to_excel(writer, sheet_name="Summary", index=False)
        proposals_to_frame(proposals).to_excel(writer, sheet_name="Match Evidence", index=False)
        pd.DataFrame(exceptions).to_excel(writer, sheet_name="Exceptions", index=False)

    buffer.seek(0)
    wb = load_workbook(buffer)
    for ws in wb.worksheets:
        ws.freeze_panes = "A2"
        for cell in ws[1]:
            cell.font = Font(bold=True)

    output = BytesIO()
    wb.save(output)
    output.seek(0)
    return output


def build_pdf_report(result, proposals, exceptions):
    output = BytesIO()
    doc = SimpleDocTemplate(output, pagesize=A4)
    styles = getSampleStyleSheet()
    story = [
        Paragraph("Bank Reconciliation Report", styles["Title"]),
        Spacer(1, 12),
        Paragraph(f"Status: {result.status}", styles["Heading2"]),
    ]

    rows = [
        ["Metric", "Value"],
        ["Bank total", str(result.bank_total)],
        ["Ledger total", str(result.ledger_total)],
        ["Matched bank total", str(result.matched_bank_total)],
        ["Matched ledger total", str(result.matched_ledger_total)],
        ["Unmatched bank total", str(result.unmatched_bank_total)],
        ["Unmatched ledger total", str(result.unmatched_ledger_total)],
        ["Difference", str(result.difference)],
    ]
    table = Table(rows)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    story.extend([table, Spacer(1, 15)])
    story.append(Paragraph(f"Match proposals: {len(proposals)}", styles["BodyText"]))
    story.append(Paragraph(f"Exceptions: {len(exceptions)}", styles["BodyText"]))
    doc.build(story)
    output.seek(0)
    return output
