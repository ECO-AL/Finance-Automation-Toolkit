from pathlib import Path
import pandas as pd


def generate_sample_data(output_dir="sample_data"):
    output = Path(output_dir)
    output.mkdir(exist_ok=True)

    bank = pd.DataFrame([
        ["B001", "2026-09-01", "CUSTOMER PAYMENT A", "REF1001", "1000.00", "credit", "KES"],
        ["B002", "2026-09-02", "BANK CHARGE", "CHG01", "25.00", "debit", "KES"],
        ["B003", "2026-09-03", "CUSTOMER PAYMENT B", "REF1002", "2500.00", "credit", "KES"],
        ["B004", "2026-09-05", "CUSTOMER PAYMENT C", "REF1003", "1200.00", "credit", "KES"],
        ["B005", "2026-09-07", "SUPPLIER PAYMENT", "PAY2001", "700.00", "debit", "KES"],
        ["B006", "2026-09-08", "DUPLICATE PAYMENT", "REF1004", "500.00", "credit", "KES"],
    ], columns=["transaction_id","transaction_date","description","reference","amount","direction","currency"])

    ledger = pd.DataFrame([
        ["L001", "2026-09-01", "CUSTOMER PAYMENT A", "REF1001", "1000.00", "credit", "KES"],
        ["L002", "2026-09-03", "CUSTOMER PAYMENT B", "REF1002", "2500.00", "credit", "KES"],
        ["L003", "2026-09-06", "CUSTOMER PAYMENT C", "REF1003", "1200.00", "credit", "KES"],
        ["L004", "2026-09-07", "SUPPLIER PAYMENT", "PAY2001", "700.00", "debit", "KES"],
        ["L005", "2026-09-08", "DUPLICATE PAYMENT", "REF1004", "500.00", "credit", "KES"],
        ["L006", "2026-09-08", "DUPLICATE PAYMENT", "REF1004", "500.00", "credit", "KES"],
    ], columns=bank.columns)

    bank.to_csv(output / "bank_statement.csv", index=False)
    ledger.to_csv(output / "ledger.csv", index=False)


if __name__ == "__main__":
    generate_sample_data()
