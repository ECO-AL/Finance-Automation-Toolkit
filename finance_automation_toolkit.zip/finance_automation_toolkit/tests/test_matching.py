import pandas as pd
from decimal import Decimal
from finance_toolkit.normalization import normalize_frame
from finance_toolkit.matching import propose_matches, detect_group_candidates
from finance_toolkit.models import ReconciliationConfig


def frames():
    bank = pd.DataFrame({
        "transaction_id": ["B1", "B2"],
        "transaction_date": ["2026-09-01", "2026-09-03"],
        "description": ["Customer payment", "Supplier payment"],
        "reference": ["REF1", "REF2"],
        "amount": ["100.00", "300.00"],
        "direction": ["credit", "debit"],
    })
    ledger = pd.DataFrame({
        "transaction_id": ["L1", "L2"],
        "transaction_date": ["2026-09-01", "2026-09-04"],
        "description": ["Customer payment", "Supplier payment"],
        "reference": ["REF1", "REF2"],
        "amount": ["100.00", "300.00"],
        "direction": ["credit", "debit"],
    })
    mapping = {c: c for c in bank.columns}
    return (
        normalize_frame(bank, mapping, "bank"),
        normalize_frame(ledger, mapping, "ledger")
    )


def test_exact_matches_are_proposed():
    bank, ledger = frames()
    proposals = propose_matches(bank, ledger, ReconciliationConfig())
    assert proposals[0].ledger_ids == ["L1"]
    assert proposals[0].score >= 0.75


def test_group_candidate():
    bank = pd.DataFrame({
        "transaction_id": ["B1"],
        "transaction_date": ["2026-09-01"],
        "description": ["Combined deposit"],
        "reference": [""],
        "amount": ["100.00"],
        "direction": ["credit"],
    })
    ledger = pd.DataFrame({
        "transaction_id": ["L1", "L2"],
        "transaction_date": ["2026-09-01", "2026-09-01"],
        "description": ["Part A", "Part B"],
        "reference": ["", ""],
        "amount": ["40.00", "60.00"],
        "direction": ["credit", "credit"],
    })
    mapping = {c: c for c in bank.columns}
    b = normalize_frame(bank, mapping, "bank")
    l = normalize_frame(ledger, mapping, "ledger")
    groups = detect_group_candidates(b, l, ReconciliationConfig())
    assert any(x["bank_id"] == "B1" and x["ledger_ids"] == ["L1", "L2"] for x in groups)
