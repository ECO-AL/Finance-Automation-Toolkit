import pandas as pd
from decimal import Decimal
from finance_toolkit.normalization import normalize_frame
from finance_toolkit.reconciliation import calculate_reconciliation


def test_reconciliation_balances_when_all_items_are_approved():
    bank = pd.DataFrame({
        "transaction_id": ["B1"],
        "transaction_date": ["2026-09-01"],
        "description": ["Payment"],
        "amount": ["100.00"],
        "direction": ["credit"],
    })
    ledger = pd.DataFrame({
        "transaction_id": ["L1"],
        "transaction_date": ["2026-09-01"],
        "description": ["Payment"],
        "amount": ["100.00"],
        "direction": ["credit"],
    })
    mapping = {c: c for c in bank.columns}
    b = normalize_frame(bank, mapping, "bank")
    l = normalize_frame(ledger, mapping, "ledger")
    result = calculate_reconciliation(b, l, [("B1", "L1")])
    assert result.status == "RECONCILED"
    assert result.difference == Decimal("0")
