import pandas as pd
from decimal import Decimal
from finance_toolkit.normalization import normalize_frame
from finance_toolkit.validation import validate_transactions


def make_df():
    return pd.DataFrame({
        "transaction_id": ["A1", "A2"],
        "transaction_date": ["2026-09-01", "2026-09-02"],
        "description": ["Payment", "Charge"],
        "amount": ["100.00", "10.00"],
        "direction": ["credit", "debit"],
    })


def test_normalization():
    df = normalize_frame(make_df(), {
        "transaction_id": "transaction_id",
        "transaction_date": "transaction_date",
        "description": "description",
        "amount": "amount",
        "direction": "direction",
    }, "bank")
    assert df.loc[0, "amount"] == Decimal("100.00")
    assert str(df.loc[0, "transaction_date"]) == "2026-09-01"


def test_validation_passes():
    df = normalize_frame(make_df(), {
        "transaction_id": "transaction_id",
        "transaction_date": "transaction_date",
        "description": "description",
        "amount": "amount",
        "direction": "direction",
    }, "bank")
    assert validate_transactions(df)["valid"] is True
