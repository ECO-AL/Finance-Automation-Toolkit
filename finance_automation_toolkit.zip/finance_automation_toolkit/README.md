# Finance Automation Toolkit

A Python and Streamlit bank reconciliation application designed for accountants and finance teams.

## Purpose

The toolkit imports bank and general ledger transactions, validates and normalises them, proposes matches using transparent rules, identifies exceptions, calculates reconciliation results, and produces an auditable report.

It does not post accounting entries and it does not silently force low confidence matches.

## Features

- CSV and Excel input
- Flexible column mapping
- Data quality validation
- Monetary values represented with Decimal
- Duplicate detection
- Exact and tolerance based matching
- Reference and description similarity
- One to many and many to one candidate detection
- Manual approval and rejection workflow in the UI
- Reconciliation summary
- Exception classification
- Excel report export
- PDF report export
- Synthetic test data
- Automated tests

## Project structure

```text
finance_automation_toolkit/
  finance_toolkit/
    __init__.py
    models.py
    validation.py
    normalization.py
    matching.py
    reconciliation.py
    reporting.py
    sample_data.py
    app.py
  tests/
    test_validation.py
    test_matching.py
    test_reconciliation.py
  sample_data/
    bank_statement.csv
    ledger.csv
  requirements.txt
  README.md
```

## Input schema

The application can work with common aliases, but these canonical fields are recommended.

Bank:
- transaction_id
- transaction_date
- description
- reference
- amount
- direction
- currency

Ledger:
- transaction_id
- transaction_date
- description
- reference
- amount
- direction
- currency

`direction` should be `debit` or `credit`. If a source uses signed amounts, the normalisation layer converts them into an absolute amount plus direction.

## Matching methodology

The engine uses progressively stronger evidence:

1. Exact amount, direction and reference.
2. Exact amount and close date.
3. Exact amount, close date and description similarity.
4. Exact amount, close date and partial reference.
5. Candidate one to many or many to one combinations.
6. Manual review when evidence is insufficient or ambiguous.

Confidence is an evidence score, not a claim that the accounting treatment is correct.

Default matching tolerances:
- Date tolerance: 2 days
- Amount tolerance: 0.01
- Description similarity: 0.72

These are configurable.

## Controls

A proposed match becomes `matched` only after explicit approval in the interface. Automated suggestions remain visible in the audit trail.

The application does not create journal entries automatically.

## Run locally

```bash
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS/Linux:
```bash
source .venv/bin/activate
```

Install:
```bash
pip install -r requirements.txt
```

Run tests:
```bash
pytest -q
```

Run the application:
```bash
streamlit run finance_toolkit/app.py
```

## Privacy

This project is designed for local processing. Uploaded financial files are processed by the local application. Do not connect production financial data to external services unless your organisation has authorised that architecture.

## Limitations

- Source systems may contain accounting semantics that cannot be inferred safely from transaction text alone.
- Complex bank formats may require custom mappings.
- One to many and many to one detection is intentionally conservative.
- Description similarity can produce false positives.
- Human review remains necessary for exceptions and accounting adjustments.
- PDF export requires a compatible ReportLab installation.

## Future modules

- Accounts receivable ageing
- Accounts payable matching
- Invoice extraction
- Expense reconciliation
- Cash flow forecasting
- Inventory reconciliation
- Financial reporting automation
- ERP integration with explicit approval controls
